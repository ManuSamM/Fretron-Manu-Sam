#include<iostream>
#include<vector>
using namespace std;

void backtrack(int& ans, vector<vector<int>> chess, int x, int y, string direction, bool started)
{
    if(direction == "down")
    {
        for(int i = x; i < 10; i++)
        {
            if(chess[i][y] == 1)
            {
                chess[i][y] = 0;
                backtrack(ans, chess, i, y, "right", true);
            }
            else if(started == true && chess[i][y] == 10)
            {
                ans++;
                return;
            }
        }
    }
    else if(direction == "right")
    {
        for(int i = y; i < 10; i++)
        {
            if(chess[x][i] == 1)
            {
                chess[x][i] = 0;
                backtrack(ans, chess, x, i, "up", true);
            }
            else if(started == true && chess[x][i] == 10)
            {
                ans++;
                return;
            }
        }
    }
    else if(direction == "up")
    {
        for(int i = x; i >= 0; i--)
        {
            if(chess[i][y] == 1)
            {
                chess[i][y] = 0;
                backtrack(ans, chess, i, y, "left", true);
            }
            else if(started == true && chess[i][y] == 10)
            {
                ans++;
                return;
            }
        }
    }
    else if(direction == "left")
    {
        for(int i = y; i >= 0; i++)
        {
            if(chess[x][i] == 1)
            {
                chess[x][i] = 0;
                backtrack(ans, chess, x, i, "down", true);
            }
            else if(started == true && chess[x][i] == 10)
            {
                ans++;
                return;
            }
        }
    }


}
int main()
{
    vector<vector<int>> chess(10, vector<int>(10, 0));
    int n;

    cout<<"find_my_home_castle -soldiers ";
    cin>>n;

    for(int i = 1; i <= n; i++)
    {
        cout<<"Enter coordinates for soldier "<<i<<": ";
        int x, y;
        cin>>x>>y;
        chess[x][y] = 1;
    }

    cout<<"Enter the coordinates for your �special� castle: ";
    int x, y;
    cin>>x>>y;
    chess[x][y] = 10;

    int ans = 0;
    backtrack(ans, chess, x, y, "down", false);
    cout<<ans;

}
