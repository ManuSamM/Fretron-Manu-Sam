import matplotlib.pyplot as plt

flight1X = [1, 2, 3]
flight1Y = [1, 2, 3]

flight2X = [1, 2, 3]
flight2Y = [1, 4, 2]

flight3X = [1, 4, 3]
flight3Y = [1, 2, 4]

# plot lines
plt.plot(flight1X, flight1Y, label="Flight 1", marker = 'o')
plt.plot(flight2X, flight2Y, label="Flight 2", marker = 'o')
plt.plot(flight3X, flight3Y, label="Flight 3", marker = 'o')

plt.legend()
plt.grid()
plt.show()
