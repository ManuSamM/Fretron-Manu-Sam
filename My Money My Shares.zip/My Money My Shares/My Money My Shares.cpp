#include<iostream>
#include<deque>
#include<vector>
#include<algorithm>
using namespace std;
int main()
{
    cout<<"run distribute_apple"<<endl;

    deque<int> apple;
    int weight;
    double total = 0.0;

    while(true)
    {
        cout<<"Enter apple weight in gram (-1 to stop ) :";
        cin>>weight;
        if(weight == -1)
            break;
        apple.push_back(weight);
        total += weight;
    }

    double ram = 50.0 / 100.0 * total;
    double sham = 30.0 / 100.0 * total;
    double rahim = 20.0 / 100.0 * total;

    sort(apple.begin(), apple.end());

    vector<vector<int>> destributions(3);

    vector<double> people;

    people.push_back(ram);
    people.push_back(sham);
    people.push_back(rahim);

    int i = 0;

    while(i < 3)
    {
        int right = apple.back();
        int left = apple.front();
        if(right <= people[i])
        {
            destributions[i].push_back(right);
            people[i] -= right;
            apple.pop_back();
        }
        else if(left <= people[i])
        {
            destributions[i].push_back(left);
            people[i] -= left;
            apple.pop_front();
        }
        else
            i++;
    }

    cout<<"Distribution Result:"<<endl;

    cout<<"Ram: ";
    for(int i = 0; i < destributions[0].size(); i++)
    {
        cout<<destributions[0][i]<<" ";
    }
    cout<<endl;

    cout<<"Sham: ";
    for(int i = 0; i < destributions[1].size(); i++)
    {
        cout<<destributions[1][i]<<" ";
    }
    cout<<endl;

    cout<<"Rahim: ";
    for(int i = 0; i < destributions[2].size(); i++)
    {
        cout<<destributions[2][i]<<" ";
    }
    cout<<endl;

    return 0;
}
